"""Input and output helpers for matching-quality evaluation."""

from __future__ import annotations

from pathlib import Path

import pandas as pd


SUPPORTED_SUFFIXES = {".csv", ".json", ".jsonl", ".parquet"}


def read_table(path: str | Path) -> pd.DataFrame:
    """Read a tabular file into a DataFrame."""
    file_path = Path(path)
    suffix = file_path.suffix.lower()

    if suffix == ".csv":
        return pd.read_csv(file_path)
    if suffix == ".json":
        return pd.read_json(file_path)
    if suffix == ".jsonl":
        return pd.read_json(file_path, lines=True)
    if suffix == ".parquet":
        return pd.read_parquet(file_path)

    supported = ", ".join(sorted(SUPPORTED_SUFFIXES))
    raise ValueError(f"Unsupported file type '{suffix}'. Supported: {supported}")


def write_report(report: dict, path: str | Path | None) -> None:
    """Write a JSON report when a path is provided."""
    if path is None:
        return

    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    pd.Series(report).to_json(output_path, indent=2, force_ascii=False)
