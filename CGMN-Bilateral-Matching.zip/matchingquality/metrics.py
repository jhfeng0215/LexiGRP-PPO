"""Core matching-quality metrics."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Iterable

import numpy as np
import pandas as pd
from scipy.optimize import linear_sum_assignment


@dataclass(frozen=True)
class MatchingQualityReport:
    """Summary of predicted bilateral matching quality."""

    predicted_pairs: int
    reference_pairs: int
    true_positive_pairs: int
    precision: float
    recall: float
    f1: float
    average_score: float | None
    score_coverage: float | None

    def to_dict(self) -> dict:
        return asdict(self)


def _pair_set(frame: pd.DataFrame, left_col: str, right_col: str) -> set[tuple[str, str]]:
    if left_col not in frame.columns or right_col not in frame.columns:
        missing = [col for col in (left_col, right_col) if col not in frame.columns]
        raise ValueError(f"Missing required column(s): {', '.join(missing)}")

    pairs = frame[[left_col, right_col]].dropna().astype(str)
    return set(map(tuple, pairs.itertuples(index=False, name=None)))


def _safe_divide(numerator: int, denominator: int) -> float:
    return numerator / denominator if denominator else 0.0


def evaluate_matching_quality(
    predicted: pd.DataFrame,
    reference: pd.DataFrame,
    *,
    left_col: str = "left_id",
    right_col: str = "right_id",
    score_col: str | None = "score",
) -> MatchingQualityReport:
    """Compare predicted pairs with reference pairs."""
    predicted_pairs = _pair_set(predicted, left_col, right_col)
    reference_pairs = _pair_set(reference, left_col, right_col)
    true_positive_pairs = len(predicted_pairs & reference_pairs)

    precision = _safe_divide(true_positive_pairs, len(predicted_pairs))
    recall = _safe_divide(true_positive_pairs, len(reference_pairs))
    f1 = _safe_divide(2 * precision * recall, precision + recall)

    average_score = None
    score_coverage = None
    if score_col and score_col in predicted.columns:
        scores = pd.to_numeric(predicted[score_col], errors="coerce")
        valid_scores = scores.dropna()
        average_score = float(valid_scores.mean()) if not valid_scores.empty else None
        score_coverage = float(valid_scores.size / len(predicted)) if len(predicted) else 0.0

    return MatchingQualityReport(
        predicted_pairs=len(predicted_pairs),
        reference_pairs=len(reference_pairs),
        true_positive_pairs=true_positive_pairs,
        precision=float(precision),
        recall=float(recall),
        f1=float(f1),
        average_score=average_score,
        score_coverage=score_coverage,
    )


def select_best_bilateral_matches(
    candidates: pd.DataFrame,
    *,
    left_col: str = "left_id",
    right_col: str = "right_id",
    score_col: str = "score",
) -> pd.DataFrame:
    """Select a maximum-score one-to-one matching from candidate pairs."""
    required = {left_col, right_col, score_col}
    missing = sorted(required - set(candidates.columns))
    if missing:
        raise ValueError(f"Missing required column(s): {', '.join(missing)}")

    scored = candidates[[left_col, right_col, score_col]].dropna().copy()
    if scored.empty:
        return scored

    scored[score_col] = pd.to_numeric(scored[score_col], errors="coerce")
    scored = scored.dropna(subset=[score_col])
    if scored.empty:
        return scored

    scored[left_col] = scored[left_col].astype(str)
    scored[right_col] = scored[right_col].astype(str)
    left_values = list(dict.fromkeys(scored[left_col].astype(str)))
    right_values = list(dict.fromkeys(scored[right_col].astype(str)))
    left_index = {value: idx for idx, value in enumerate(left_values)}
    right_index = {value: idx for idx, value in enumerate(right_values)}

    score_matrix = np.full((len(left_values), len(right_values)), -np.inf)
    for row in scored.to_dict("records"):
        left_value = row[left_col]
        right_value = row[right_col]
        score = row[score_col]
        score_matrix[left_index[str(left_value)], right_index[str(right_value)]] = max(
            score_matrix[left_index[str(left_value)], right_index[str(right_value)]],
            float(score),
        )

    finite_scores = score_matrix[np.isfinite(score_matrix)]
    if finite_scores.size == 0:
        return scored.iloc[0:0]

    penalty = finite_scores.min() - abs(finite_scores.min()) - 1.0
    cost_matrix = -np.where(np.isfinite(score_matrix), score_matrix, penalty)
    left_rows, right_rows = linear_sum_assignment(cost_matrix)

    selected_pairs: Iterable[tuple[str, str]] = (
        (left_values[left_idx], right_values[right_idx])
        for left_idx, right_idx in zip(left_rows, right_rows, strict=False)
        if np.isfinite(score_matrix[left_idx, right_idx])
    )
    selected = pd.DataFrame(selected_pairs, columns=[left_col, right_col])
    return selected.merge(scored, on=[left_col, right_col], how="left")
