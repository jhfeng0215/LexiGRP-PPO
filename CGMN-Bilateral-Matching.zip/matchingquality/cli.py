"""Command-line interface for matching-quality evaluation."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from matchingquality.io import read_table, write_report
from matchingquality.metrics import evaluate_matching_quality, select_best_bilateral_matches


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Evaluate bilateral matching quality.")
    parser.add_argument("--predicted", required=True, help="Predicted matching file.")
    parser.add_argument("--reference", required=True, help="Reference matching file.")
    parser.add_argument("--left-col", default="left_id", help="Left entity id column.")
    parser.add_argument("--right-col", default="right_id", help="Right entity id column.")
    parser.add_argument("--score-col", default="score", help="Optional score column in predicted data.")
    parser.add_argument("--output", help="Optional JSON report output path.")
    parser.add_argument(
        "--select-best",
        action="store_true",
        help="Convert candidate pairs into a maximum-score one-to-one matching before evaluation.",
    )
    return parser


def main() -> int:
    args = build_parser().parse_args()
    predicted = read_table(args.predicted)
    reference = read_table(args.reference)

    if args.select_best:
        predicted = select_best_bilateral_matches(
            predicted,
            left_col=args.left_col,
            right_col=args.right_col,
            score_col=args.score_col,
        )

    report = evaluate_matching_quality(
        predicted,
        reference,
        left_col=args.left_col,
        right_col=args.right_col,
        score_col=args.score_col,
    )
    payload = report.to_dict()

    print(json.dumps(payload, indent=2, ensure_ascii=False))
    write_report(payload, Path(args.output) if args.output else None)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
