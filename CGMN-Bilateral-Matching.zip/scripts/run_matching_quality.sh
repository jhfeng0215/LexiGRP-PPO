#!/usr/bin/env bash
set -euo pipefail

python run_matching_quality.py "$@"
