# CGMN Bilateral Matching

This repository contains a small, runnable Python toolkit for evaluating bilateral matching quality.

The code is organized as a normal package instead of a temporary `main_xx.py` style script:

- `matchingquality/metrics.py` implements matching metrics and one-to-one best-match selection.
- `matchingquality/io.py` handles CSV, JSON, JSONL, and Parquet input.
- `matchingquality/cli.py` provides the command-line interface.
- `run_matching_quality.py` is the root entry point.
- `scripts/run_matching_quality.sh` is a shell wrapper for repeatable runs.

## Installation

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Quick Start

Run the included example:

```bash
bash scripts/run_matching_quality.sh \
  --predicted examples/predicted.csv \
  --reference examples/reference.csv
```

Write the report to a JSON file:

```bash
bash scripts/run_matching_quality.sh \
  --predicted examples/predicted.csv \
  --reference examples/reference.csv \
  --output outputs/example_report.json
```

If the predicted file contains multiple candidate pairs with a `score` column, select the maximum-score one-to-one bilateral matching before evaluation:

```bash
bash scripts/run_matching_quality.sh \
  --predicted examples/predicted.csv \
  --reference examples/reference.csv \
  --select-best
```

## Input Format

By default, both predicted and reference files should contain:

| Column | Description |
| --- | --- |
| `left_id` | Identifier from the left side of the bilateral match. |
| `right_id` | Identifier from the right side of the bilateral match. |
| `score` | Optional predicted confidence or matching quality score. |

Custom column names are supported:

```bash
python run_matching_quality.py \
  --predicted path/to/predicted.csv \
  --reference path/to/reference.csv \
  --left-col source_id \
  --right-col target_id \
  --score-col matching_score
```

## Metrics

The report contains:

- `predicted_pairs`: number of unique predicted pairs.
- `reference_pairs`: number of unique reference pairs.
- `true_positive_pairs`: predicted pairs that also appear in the reference.
- `precision`: `true_positive_pairs / predicted_pairs`.
- `recall`: `true_positive_pairs / reference_pairs`.
- `f1`: harmonic mean of precision and recall.
- `average_score`: mean score in the predicted file when a score column is present.
- `score_coverage`: fraction of predicted rows with valid numeric scores.

## Development Notes

The implementation keeps data loading, metric computation, and command-line parsing separate so each part can be tested and maintained independently.
