"""Run the matching-quality command-line interface."""

from matchingquality.cli import main


if __name__ == "__main__":
    raise SystemExit(main())
